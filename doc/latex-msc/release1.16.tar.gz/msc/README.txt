MSC Macro Package
-----------------
Version 1.16 
June 2, 2008

----------------------------------------------------------------------
Copyright 2008 V. Bos, T. van Deursen, and S. Mauw

This work may be distributed and/or modified under the
conditions of the LaTeX Project Public License, either version 1.3
of this license or (at your option) any later version.
The latest version of this license is in
  http://www.latex-project.org/lppl.txt
and version 1.3 or later is part of all distributions of LaTeX
version 2005/12/01 or later.

This program consists of the files 
  msc.sty
  manual.tex
  manual.pdf
  refman.tex
  refman.pdf
  biblio.bib
  maintenance.tex
  maintenance.pdf
  README
  COPYRIGHT

----------------------------------------------------------------------

The MSC macro package is a LaTeX2e package to draw MSC diagrams. See
user manual (manual.pdf) and reference manual (refman.pdf) for more
information.

Contact address:
Ton van Deursen
Universit\'e du Luxembourg 
Facult\'e des Sciences, de la Technologie et de la Communication
6, rue Richard Coudenhove-Kalergi
L-1359 Luxembourg
Email: ton.vandeursen@uni.lu
Updates via: http://satoss.uni.lu/mscpackage/
